import pandas as pd
import xml.etree.ElementTree as ET
from collections import defaultdict


def __xml_to_dict(t: ET.Element) -> dict:
    d = {t.tag: {} if t.attrib else None}
    children = list(t)
    
    if children:
        dd = defaultdict(list)
        
        for dc in map(__xml_to_dict, children):
            for k, v in dc.items():
                dd[k].append(v)
                
        d = {t.tag: {k: v[0] if len(v) == 1 else v for k, v in dd.items()}}
        
    if t.attrib:
        d[t.tag].update(('@' + k, v) for k, v in t.attrib.items())
        
    if t.text:
        text = t.text.strip()
        if children or t.attrib:
            if text:
                d[t.tag]['#text'] = text
        else:
            d[t.tag] = text
            
    return d


def get_xml_data(path: str) -> pd.DataFrame:
    tree = ET.parse(path).getroot()
    data_dict = __xml_to_dict(tree)
    
    ts_list = data_dict\
        ['{http://www.boschrexroth.de/indraworks.textformatter.xsd}root']\
        ['{http://www.boschrexroth.de/indraworks.textformatter.xsd}OscilloscopeData'] \
        ['{http://www.boschrexroth.de/indraworks.textformatter.xsd}Devices'] \
        ['{http://www.boschrexroth.de/indraworks.textformatter.xsd}Device'] \
        ['{http://www.boschrexroth.de/indraworks.textformatter.xsd}Measurements']\
        ['{http://www.boschrexroth.de/indraworks.textformatter.xsd}Measurement']\
        ['{http://www.boschrexroth.de/indraworks.textformatter.xsd}Signals']\
        ['{http://www.boschrexroth.de/indraworks.textformatter.xsd}Signal']

    ts_dict = {}
    
    name_dict = {
        'S-0-0047.0.0 Position command value':'pcv',
        'S-0-0051.0.0 Position feedback value 1':'pfv',
        'S-0-0040.0.0 Velocity feedback value':'vfv',
        'P-0-0440.0.0 Actual output current value (absolute value)':'cv'
    }
    
    for ts in ts_list:
        ts_dict[name_dict[ts['{http://www.boschrexroth.de/indraworks.textformatter.xsd}Name']]] = {
            'x':[float(i) for i in ts['{http://www.boschrexroth.de/indraworks.textformatter.xsd}XValue'].split('|')],
            'y':[float(i) for i in ts['{http://www.boschrexroth.de/indraworks.textformatter.xsd}YValue'].split('|')]
        }
        
    df = pd.DataFrame()
    
    for k, v in ts_dict.items():
        for a, s in v.items():
            df[str(k)+'_'+str(a)] = s
        
    return df


def get_reversed_name_dict() -> dict:
    name_dict = {
        'S-0-0047.0.0 Position command value':'pcv',
        'S-0-0051.0.0 Position feedback value 1':'pfv',
        'S-0-0040.0.0 Velocity feedback value':'vfv',
        'P-0-0440.0.0 Actual output current value (absolute value)':'cv'
    }
    
    return {name_dict[x]: x for x in name_dict.keys()}

